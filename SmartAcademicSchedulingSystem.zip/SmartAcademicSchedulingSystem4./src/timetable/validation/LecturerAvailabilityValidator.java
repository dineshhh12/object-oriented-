
package timetable.validation;

import java.util.List;
import timetable.model.ClassSession;
import timetable.model.LecturerAvailability;
import timetable.model.TimeSlot;

public class LecturerAvailabilityValidator {

    public String validate(
            ClassSession session,
            List<LecturerAvailability> availabilityList) {

        String lecturerId = session.getLecturer().getLecturerId();
        TimeSlot slot = session.getTimeSlot();

        for (LecturerAvailability availability : availabilityList) {
            if (availability.getLecturerId().equals(lecturerId)
                    && availability.covers(
                            slot.getDate(),
                            slot.getStartTime(),
                            slot.getEndTime())) {
                return null; // Lecturer is available
            }
        }

        return "Lecturer " + lecturerId
                + " is not available for this date and time.";
    }
}
