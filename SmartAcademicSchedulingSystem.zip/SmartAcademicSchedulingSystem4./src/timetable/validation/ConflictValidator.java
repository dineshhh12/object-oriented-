
package timetable.validation;

import java.util.ArrayList;
import java.util.List;

import timetable.model.ClassSession;

public class ConflictValidator {

    public List<String> validate(
            ClassSession proposed,
            List<ClassSession> existingSessions) {

        List<String> errors = new ArrayList<>();

        if (proposed.getRoom().getCapacity()
                < proposed.getStudentGroup().getStudentCount()) {
            errors.add("Room capacity is insufficient for "
                    + proposed.getSessionId());
        }

        if (proposed.getCourse().requiresLaboratory()
                && !"LABORATORY".equals(
                        proposed.getRoom().getRoomType())) {
            errors.add("A laboratory is required for "
                    + proposed.getSessionId());
        }

        for (ClassSession existing : existingSessions) {
            if (existing.getSessionId().equals(proposed.getSessionId())) {
                continue;
            }

            if (!proposed.getTimeSlot().overlaps(existing.getTimeSlot())) {
                continue;
            }

            if (proposed.getLecturer().getLecturerId()
                    .equals(existing.getLecturer().getLecturerId())) {
                errors.add("Lecturer conflict: "
                        + proposed.getLecturer().getName());
            }

            if (proposed.getStudentGroup().getGroupId()
                    .equals(existing.getStudentGroup().getGroupId())) {
                errors.add("Student group conflict: "
                        + proposed.getStudentGroup().getGroupName());
            }

            if (proposed.getRoom().getRoomId()
                    .equals(existing.getRoom().getRoomId())) {
                errors.add("Room conflict: "
                        + proposed.getRoom().getRoomId());
            }
        }

        return errors;
    }
}
