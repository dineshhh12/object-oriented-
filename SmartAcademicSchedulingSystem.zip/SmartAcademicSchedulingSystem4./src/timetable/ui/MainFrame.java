
package timetable.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

import timetable.model.ClassSession;
import timetable.scheduling.SchedulingService;
import timetable.scheduling.SchedulingStrategy;
import timetable.scheduling.Timetable;
import timetable.api.TimetableExportQueue;
import timetable.model.ClassSession;
import timetable.scheduling.Timetable;


public class MainFrame extends JFrame {

    private final SchedulingService service;
    private final List<ClassSession> requestedSessions;

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new String[]{
                    "Session ID", "Course", "Lecturer",
                    "Student Group", "Room", "Date",
                    "Start Time", "End Time"
            }, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

    public MainFrame(SchedulingService service,
                     List<ClassSession> requestedSessions,
                     SchedulingStrategy greedy,
                     SchedulingStrategy backtracking) {

        this.service = service;
        this.requestedSessions = List.copyOf(requestedSessions);

        setTitle("Smart Academic Scheduling System");
        setSize(1000, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTable table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton validateButton = new JButton("Validate Timetable");
        JButton greedyButton = new JButton("Generate (Greedy)");
        JButton backtrackingButton =
                new JButton("Generate (Backtracking)");

        JPanel panel = new JPanel(new FlowLayout());
        panel.add(validateButton);
        panel.add(greedyButton);
        panel.add(backtrackingButton);
        add(panel, BorderLayout.SOUTH);

        validateButton.addActionListener(e -> validateInBackground());
        greedyButton.addActionListener(
                e -> generateInBackground(greedy));
        backtrackingButton.addActionListener(
                e -> generateInBackground(backtracking));

        displaySessions(this.requestedSessions);
    }

    private void validateInBackground() {
        new SwingWorker<List<String>, Void>() {
            @Override
            protected List<String> doInBackground() {
                return service.validateSessions(requestedSessions);
            }

            @Override
            protected void done() {
                try {
                    List<String> errors = get();

                    if (errors.isEmpty()) {
                        JOptionPane.showMessageDialog(
                                MainFrame.this,
                                "No timetable conflicts found.");
                    } else {
                        JOptionPane.showMessageDialog(
                                MainFrame.this,
                                String.join("\n", errors),
                                "Validation Results",
                                JOptionPane.WARNING_MESSAGE);
                    }
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Validation was interrupted.");
                } catch (ExecutionException ex) {
                    showError("Validation failed: "
                            + ex.getCause().getMessage());
                }
            }
        }.execute();
    }


private void generateInBackground(SchedulingStrategy strategy) {

    new SwingWorker<Timetable, Void>() {

        @Override
        protected Timetable doInBackground() {
            return service.generateTimetable(
                    requestedSessions, strategy);
        }

        @Override
        protected void done() {
            try {
                Timetable timetable = get();

                // Export timetable records
                TimetableExportQueue exportQueue =
                        new TimetableExportQueue();

                for (ClassSession session : timetable.getSessions()) {
                    boolean added = exportQueue.enqueue(session);

                    if (!added) {
                        System.out.println(
                                "Duplicate session skipped: "
                                + session.getSessionId());
                    }
                }

                exportQueue.processQueue();

                // Update your timetable table here
                // Keep your existing table-refresh code, if any.

            } catch (Exception e) {
                e.printStackTrace();

                javax.swing.JOptionPane.showMessageDialog(
                        MainFrame.this,
                        "Failed to generate timetable: "
                                + e.getMessage(),
                        "Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        }

    }.execute();
}


    private void displaySessions(List<ClassSession> sessions) {
        tableModel.setRowCount(0);

        for (ClassSession session : sessions) {
            tableModel.addRow(new Object[]{
                    session.getSessionId(),
                    session.getCourse().getCourseName(),
                    session.getLecturer().getName(),
                    session.getStudentGroup().getGroupName(),
                    session.getRoom().getRoomId(),
                    session.getTimeSlot().getDate(),
                    session.getTimeSlot().getStartTime(),
                    session.getTimeSlot().getEndTime()
            });
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this, message,
                "Smart Academic Scheduling System - Error",
                JOptionPane.ERROR_MESSAGE);
       
    }
}
