
package timetable.repository;

import java.util.List;
import java.util.Optional;

public interface Repository<T> {
    void save(String id, T item);
    Optional<T> findById(String id);
    List<T> findAll();
    void delete(String id);
}
