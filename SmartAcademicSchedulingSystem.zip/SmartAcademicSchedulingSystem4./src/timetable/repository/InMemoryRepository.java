
package timetable.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class InMemoryRepository<T> implements Repository<T> {

    private final Map<String, T> items = new LinkedHashMap<>();

    @Override
    public void save(String id, T item) {
        if (id == null || id.isBlank() || item == null) {
            throw new IllegalArgumentException("ID and item are required.");
        }

        items.put(id, item);
    }

    @Override
    public Optional<T> findById(String id) {
        return Optional.ofNullable(items.get(id));
    }

    @Override
    public List<T> findAll() {
        return new ArrayList<>(items.values());
    }

    @Override
    public void delete(String id) {
        items.remove(id);
    }
}
