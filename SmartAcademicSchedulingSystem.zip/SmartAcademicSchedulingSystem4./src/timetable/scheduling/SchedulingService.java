
package timetable.scheduling;

import java.util.ArrayList;
import java.util.List;

import timetable.model.ClassSession;
import timetable.repository.Repository;
import timetable.validation.ConflictValidator;

public class SchedulingService {

    private final Repository<ClassSession> repository;
    private final ConflictValidator validator;

    public SchedulingService(Repository<ClassSession> repository,
                             ConflictValidator validator) {
        this.repository = repository;
        this.validator = validator;
    }

    public List<String> validateSessions(List<ClassSession> sessions) {
        List<String> errors = new ArrayList<>();

        for (int i = 0; i < sessions.size(); i++) {
            ClassSession current = sessions.get(i);
            List<ClassSession> others = new ArrayList<>(sessions);
            others.remove(i);

            for (String error : validator.validate(current, others)) {
                errors.add(current.getSessionId() + ": " + error);
            }
        }

        return errors;
    }

    public void saveSession(ClassSession session) {
        if (repository.findById(session.getSessionId()).isPresent()) {
            throw new IllegalArgumentException(
                    "Session ID already exists.");
        }

        List<String> errors =
                validator.validate(session, repository.findAll());

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("\n", errors));
        }

        repository.save(session.getSessionId(), session);
    }

    public List<ClassSession> getAllSessions() {
        return repository.findAll();
    }

    public Timetable generateTimetable(
            List<ClassSession> sessions, SchedulingStrategy strategy) {
        return strategy.generate(sessions);
    }
}

