
package timetable.scheduling;

import java.util.ArrayList;
import java.util.List;

import timetable.model.ClassSession;

public class Timetable {
    private final List<ClassSession> sessions = new ArrayList<>();

    public void addSession(ClassSession session) {
        if (session == null) {
            throw new IllegalArgumentException("Session cannot be null.");
        }
        sessions.add(session);
    }

    public List<ClassSession> getSessions() {
        return List.copyOf(sessions);
    }

    public int getSessionCount() {
        return sessions.size();
    }
}
