
package timetable.scheduling;

import java.util.List;

import timetable.model.ClassSession;
import timetable.validation.ConflictValidator;

public class GreedyStrategy implements SchedulingStrategy {

    private final ConflictValidator validator;

    public GreedyStrategy(ConflictValidator validator) {
        this.validator = validator;
    }

    @Override
    public Timetable generate(List<ClassSession> requestedSessions) {
        Timetable timetable = new Timetable();

        for (ClassSession session : requestedSessions) {
            if (validator.validate(
                    session, timetable.getSessions()).isEmpty()) {
                timetable.addSession(session);
            } else {
                System.out.println("Skipped session: "
                        + session.getSessionId());
            }
        }

        return timetable;
    }
}
