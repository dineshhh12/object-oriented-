
package timetable.scheduling;

import java.util.List;
import timetable.model.ClassSession;

public interface SchedulingStrategy {
    Timetable generate(List<ClassSession> requestedSessions);
}
