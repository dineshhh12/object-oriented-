
package timetable.scheduling;

import java.util.ArrayList;
import java.util.List;

import timetable.model.ClassSession;
import timetable.validation.ConflictValidator;

public class BacktrackingStrategy implements SchedulingStrategy {

    private final ConflictValidator validator;
    private List<ClassSession> bestSessions = new ArrayList<>();

    public BacktrackingStrategy(ConflictValidator validator) {
        this.validator = validator;
    }

    @Override
    public Timetable generate(List<ClassSession> requestedSessions) {
        bestSessions = new ArrayList<>();
        search(requestedSessions, 0, new ArrayList<>());

        Timetable result = new Timetable();

        for (ClassSession session : bestSessions) {
            result.addSession(session);
        }

        return result;
    }

    private void search(List<ClassSession> requested, int index,
                        List<ClassSession> selected) {

        if (selected.size() + requested.size() - index
                <= bestSessions.size()) {
            return;
        }

        if (index == requested.size()) {
            if (selected.size() > bestSessions.size()) {
                bestSessions = new ArrayList<>(selected);
            }
            return;
        }

        ClassSession candidate = requested.get(index);

        if (validator.validate(candidate, selected).isEmpty()) {
            selected.add(candidate);
            search(requested, index + 1, selected);
            selected.remove(selected.size() - 1);
        }

        search(requested, index + 1, selected);
    }
}
