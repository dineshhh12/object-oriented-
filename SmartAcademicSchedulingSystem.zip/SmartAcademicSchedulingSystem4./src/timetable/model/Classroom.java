
package timetable.model;

public class Classroom extends Room {

    public Classroom(String roomId, int capacity) {
        super(roomId, capacity);
    }

    @Override
    public String getRoomType() {
        return "CLASSROOM";
    }
}
