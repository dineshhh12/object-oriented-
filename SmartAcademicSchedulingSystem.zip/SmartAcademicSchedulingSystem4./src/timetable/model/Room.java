
package timetable.model;

public abstract class Room {
    private final String roomId;
    private final int capacity;

    public Room(String roomId, int capacity) {
        if (roomId == null || roomId.isBlank() || capacity <= 0) {
            throw new IllegalArgumentException("Invalid room details.");
        }

        this.roomId = roomId;
        this.capacity = capacity;
    }

    public String getRoomId() {
        return roomId;
    }

    public int getCapacity() {
        return capacity;
    }

    public abstract String getRoomType();
}
