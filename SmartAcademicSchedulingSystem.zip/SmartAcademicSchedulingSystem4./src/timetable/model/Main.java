
package timetable.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import javax.swing.SwingUtilities;
import timetable.repository.InMemoryRepository;
import timetable.scheduling.BacktrackingStrategy;
import timetable.scheduling.GreedyStrategy;
import timetable.scheduling.SchedulingService;
import timetable.ui.MainFrame;
import timetable.validation.ConflictValidator;

public class Main {

    public static void main(String[] args) {

        // Create courses
        Course c1 = new Course("CS101", "Programming Fundamentals", false);
        Course c2 = new Course("CS102", "Database Systems", true);
        Course c3 = new Course("CS103", "Computer Networks", false);

        // Create lecturers
        Lecturer l1 = new Lecturer("L01", "Mr Kumar");
        Lecturer l2 = new Lecturer("L02", "Ms Aisha");

        // Create student groups
        StudentGroup g1 = new StudentGroup("G01", "Group A", 25);
        StudentGroup g2 = new StudentGroup("G02", "Group B", 20);
        StudentGroup g3 = new StudentGroup("G03", "Group C", 18);

        // Create rooms
        Room r1 = new Classroom("R101", 40);
        Room r2 = new Laboratory("LAB01", 30, "Computer");
        Room r3 = new Classroom("R102", 35);

        // Create time slots for tomorrow
        LocalDate date = LocalDate.now().plusDays(1);

        TimeSlot t1 = new TimeSlot(
                date, LocalTime.of(9, 0), LocalTime.of(10, 0));
        TimeSlot t2 = new TimeSlot(
                date, LocalTime.of(9, 0), LocalTime.of(10, 0));
        TimeSlot t3 = new TimeSlot(
                date, LocalTime.of(9, 0), LocalTime.of(10, 0));

        // Create class sessions
        ClassSession s1 = new ClassSession("S001", c1, l1, g1, r1, t1);
        ClassSession s2 = new ClassSession("S002", c2, l2, g2, r2, t2);
        ClassSession s3 = new ClassSession("S003", c3, l1, g3, r3, t3);

        List<ClassSession> sessions = List.of(s1, s2, s3);

        // Initialize repository and services
        InMemoryRepository<ClassSession> repository =
                new InMemoryRepository<>();

        ConflictValidator validator = new ConflictValidator();

        SchedulingService service =
                new SchedulingService(repository, validator);

        GreedyStrategy greedy = new GreedyStrategy(validator);
        BacktrackingStrategy backtracking =
                new BacktrackingStrategy(validator);

        // Start the graphical interface
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame(
                    service, sessions, greedy, backtracking);
            frame.setVisible(true);
        });
    }
}
