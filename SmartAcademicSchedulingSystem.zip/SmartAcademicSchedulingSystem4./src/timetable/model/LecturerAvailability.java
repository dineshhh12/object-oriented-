
package timetable.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class LecturerAvailability {

    private final String lecturerId;
    private final LocalDate date;
    private final LocalTime startTime;
    private final LocalTime endTime;

    public LecturerAvailability(String lecturerId, LocalDate date,
                                LocalTime startTime, LocalTime endTime) {
        if (lecturerId == null || lecturerId.isBlank()) {
            throw new IllegalArgumentException("Lecturer ID is required.");
        }

        if (date == null || startTime == null || endTime == null
                || !startTime.isBefore(endTime)) {
            throw new IllegalArgumentException("Invalid availability time.");
        }

        this.lecturerId = lecturerId;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getLecturerId() {
        return lecturerId;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public boolean covers(LocalDate sessionDate,
                          LocalTime sessionStart,
                          LocalTime sessionEnd) {
        return date.equals(sessionDate)
                && !sessionStart.isBefore(startTime)
                && !sessionEnd.isAfter(endTime);
    }
}
