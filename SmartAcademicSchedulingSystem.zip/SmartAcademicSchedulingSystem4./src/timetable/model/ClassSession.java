
package timetable.model;

public class ClassSession {
    private final String sessionId;
    private final Course course;
    private final Lecturer lecturer;
    private final StudentGroup studentGroup;
    private final Room room;
    private final TimeSlot timeSlot;

    public ClassSession(String sessionId, Course course,
                        Lecturer lecturer, StudentGroup studentGroup,
                        Room room, TimeSlot timeSlot) {
        if (sessionId == null || sessionId.isBlank()
                || course == null || lecturer == null
                || studentGroup == null || room == null || timeSlot == null) {
            throw new IllegalArgumentException("Invalid class session details.");
        }

        this.sessionId = sessionId;
        this.course = course;
        this.lecturer = lecturer;
        this.studentGroup = studentGroup;
        this.room = room;
        this.timeSlot = timeSlot;
    }

    public String getSessionId() {
        return sessionId;
    }

    public Course getCourse() {
        return course;
    }

    public Lecturer getLecturer() {
        return lecturer;
    }

    public StudentGroup getStudentGroup() {
        return studentGroup;
    }

    public Room getRoom() {
        return room;
    }

    public TimeSlot getTimeSlot() {
        return timeSlot;
    }
}
