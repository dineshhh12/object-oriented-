
package timetable.model;

public class Laboratory extends Room {
    private final String labType;

    public Laboratory(String roomId, int capacity, String labType) {
        super(roomId, capacity);

        if (labType == null || labType.isBlank()) {
            throw new IllegalArgumentException("Laboratory type is required.");
        }

        this.labType = labType;
    }

    public String getLabType() {
        return labType;
    }

    @Override
    public String getRoomType() {
        return "LABORATORY";
    }
}
