
package timetable.model;

public class Lecturer {
    private final String lecturerId;
    private final String name;

    public Lecturer(String lecturerId, String name) {
        if (lecturerId == null || lecturerId.isBlank()
                || name == null || name.isBlank()) {
            throw new IllegalArgumentException("Invalid lecturer details.");
        }

        this.lecturerId = lecturerId;
        this.name = name;
    }

    public String getLecturerId() {
        return lecturerId;
    }

    public String getName() {
        return name;
    }
}
