
package timetable.model;

public class StudentGroup {
    private final String groupId;
    private final String groupName;
    private final int studentCount;

    public StudentGroup(String groupId, String groupName, int studentCount) {
        if (groupId == null || groupId.isBlank()
                || groupName == null || groupName.isBlank()
                || studentCount <= 0) {
            throw new IllegalArgumentException("Invalid student group details.");
        }

        this.groupId = groupId;
        this.groupName = groupName;
        this.studentCount = studentCount;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public int getStudentCount() {
        return studentCount;
    }
}
