
package timetable.api;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.swing.SwingWorker;

import timetable.model.ClassSession;

public class TimetableExportQueue {

    private final BlockingQueue<ClassSession> queue =
            new LinkedBlockingQueue<>();

    private final Set<String> queuedIds = new HashSet<>();
    private final TimetableApiAdapter adapter =
            new TimetableApiAdapter();

    public synchronized boolean enqueue(ClassSession session) {
        String id = session.getSessionId();

        if (!queuedIds.add(id)) {
            return false;
        }

        queue.offer(session);
        return true;
    }

    public void processQueue() {
        new SwingWorker<List<Map<String, String>>, Void>() {

            @Override
            protected List<Map<String, String>> doInBackground() {
                List<Map<String, String>> records = new ArrayList<>();
                ClassSession session;

                while ((session = queue.poll()) != null) {
                    records.add(adapter.toApiRecord(session));
                }

                return records;
            }

            @Override
            protected void done() {
                try {
                    List<Map<String, String>> records = get();

                    System.out.println("Prepared "
                            + records.size()
                            + " unique timetable records.");

                    for (Map<String, String> record : records) {
                        System.out.println(record);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.execute();
    }
}

