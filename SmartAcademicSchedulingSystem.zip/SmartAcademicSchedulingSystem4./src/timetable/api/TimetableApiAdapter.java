
package timetable.api;

import java.util.LinkedHashMap;
import java.util.Map;

import timetable.model.ClassSession;
import timetable.model.TimeSlot;

public class TimetableApiAdapter {

    public Map<String, String> toApiRecord(ClassSession session) {
        Map<String, String> record = new LinkedHashMap<>();
        TimeSlot slot = session.getTimeSlot();

        record.put("sessionId", session.getSessionId());
        record.put("courseId", session.getCourse().getCourseId());
        record.put("lecturerId", session.getLecturer().getLecturerId());
        record.put("studentGroupId",
                session.getStudentGroup().getGroupId());
        record.put("roomId", session.getRoom().getRoomId());
        record.put("date", slot.getDate().toString());
        record.put("startTime", slot.getStartTime().toString());
        record.put("endTime", slot.getEndTime().toString());

        return record;
    }
}

